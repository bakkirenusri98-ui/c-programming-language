// Online C compiler (editor)
// Write and run C online using this editor.

#include <stdio.h>
int main()
{
    int a=9;
    int b=3;

    printf("And operation is:%d\n",a&b);
    printf("or operation is:%d\n",a|b);
    printf("xor operation is:%d\n",a^b);
    printf("not operation is:%d\n",~a);
     return 0;
}
